package Lab01;

//Example 1: HelloWorld.java
// Text-printing program

public class HelloWorld{

    public static void main(String args[]){
        System.out.println("Hello");
        System.out.println("Ho Tuan Huy");
        System.out.println("20225856");
    }
}