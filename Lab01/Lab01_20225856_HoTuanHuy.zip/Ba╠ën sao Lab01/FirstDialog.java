package Lab01;
// Example 2: FirstDialog.java
import javax.swing.JOptionPane;
public class FirstDialog {
    public static void main(String[] args){
        JOptionPane.showMessageDialog(null, "Hello world! How are you?"); //Hien thi hop thoai
        //null: hop thoai nam giua man hinh
        System.exit(0);
    }
}
