package Lab.AimsProject.src.hust.soict.hedspi.aims.media;

public interface Playable {
    //Method to play 
    public void play();

    
}
